const fs = require('fs');
const chalk = require('chalk');

/*
 
# Note:Jangan Hapus Credits Developer Script Ini ngehapus Credit? Gw Doain Sc Nya Eror

Developer: NabzxHost
Nomor Wa:6282178006414
Telegram:T.me/nabzxstore

*/

//~~~~~~~~~< GLOBAL SETTINGS >~~~~~~~~~\\

global.owner = ['625783089587']
global.ownerUtama = "6285783089587"
global.namaOwner = "NabzxHost"
global.packname = 'Bot WhatsApp'
global.botname = 'NabzxBotzV2'
global.botname2 = 'NabzxHostV2'
global.tempatDB = 'database.json'
global.pairing_code = true
//==============================================
global.tokenbot = "7458635034:AAFKZB2NNx203anGLqdlaFBVmWEH0u-wQiU" // jangan di ganti
global.idtele = "6243990039" // ganti aja sama id tele lu ambil di T.me/getmyid_bot
//==============================================
global.linkOwner = "https://wa.me/6285783089587"
global.linkGrup = "https://chat.whatsapp.com/EiaZeImefgDIsyDBN2c1XV"
global.linkGrup2 = "https://chat.whatsapp.com/EiaZeImefgDIsyDBN2c1XV"
global.linkSaluran = "https://whatsapp.com/channel/0029Vaiz6CQ7oQha5Al83B3e"
global.idsaluran = "120363330731459003@newsletter"
global.nameChannel = "Nabzxhostganteng"
global.linkytb = 'youtube.com/@NABZXHOSTING'
global.sosmed = 't.me/nabzxstore'
//==============================================
// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 3500
global.delayPushkontak = 6000
//==============================================
// Settings buy panel otomatis 
global.apibotnabzx = "NabzxDev"
global.linkgcreseller = "https://chat.whatsapp.com/HVHCGqiPUUmDIokQ9Vv6K2"
global.merchantIdOrderKuota = "_"
global.apiOrderKuota = "_"
global.qrisOrderKuota = "_"
pinOrkut = ""
pwOrkut = ""
//==============================================
//
global.apido = "" // Api digital ocean
//==============================================
// Settings Api Panel Pterodactyl v1
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://sanmafia.marketnoxxa.biz.idd"
global.apikey = "ptla_lDV6JpeFoT4sDF4Tr25GmIFoHOX9PBxv33ggaFh4SwN" //ptla
global.capikey = "ptlc_kgs12Bppjv2BiG595TfBdzP1I2jXwbDTaNr3EHyKG2F"
//==============================================
// Settings Api Panel Pterodactyl v2
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "https://"
global.apikeyV2 = "" //ptla
global.capikeyV2 = "" //ptlc
//==============================================

//==============================================
global.dana = "081396762329"
global.ovo = "_"
global.gopay = "_"
global.qris = "_"
// Settings Api Subdomain
global.subdomain = {
"kenz-host.my.id": {
"zone": "df24766ae8eeb04b330b71b5facde5f4", 
"apitoken": "fyaxLxD0jNONtMWK3AmnaiLkkWi5Wg3Y9h8nqJh6"
},
"panelkishop.web.id": {
"zone": "8f4812b3c78ca478b5d162b6cb35d1b3", 
"apitoken": "3Y0cW3cVVIhyeWHytqFEbGDrdWaAC-k8twOEeFP2"
},
"tokopanelkishop.biz.id": {
"zone": "d87d4f320d9902f31fbbcc5ee23fafe8", 
"apitoken": "D00akOLxF3qzBzpYBp5SbpaLTmwYeybNsyAcDfiB"
},
"panelprivate.web.id": {
"zone": "61bcd80ff1ec9c3a5812f74d6ec24535", 
"apitoken": "VnjVDtbb-fSTFIn-3Hckd_E_eseqyHH7u1TTAHMN"
},
"rikionline.shop": {
"zone": "082ec80d7367d6d4f7c52600034ac635", 
"apitoken": "r3XUyNYtxNQYwZtGUIAChRqe0uTzwV4eVO7JpJ_l"
},
"market-panel.site": {
"zone": "d06bf5450ae51612a400bab1c4450283", 
"apitoken": "kmb6AkpJ6XvHMzw2m0KbYKZOycIURNYMPA7Wm0BE"
}, 
"marketnoxxa.biz.id": {
"zone": "e79846f70a8ab72bd7920e08890fc336", 
"apitoken": "G4qto3rYYjGmKyz7SWo4F_rdmNL63YRI-XIHLGJ-"
}, 
"noxxapanelvip.biz.id": {
"zone": "76318cfb99de512cc790f6b315218f77", 
"apitoken": "_T_5zhSYxX3_nfzEoiWtaLGc51nn6-AAX78WpFba"
}, 
"noxxa-hosting.biz.id": {
"zone": "397b30b0725c4f5843b8fcae025417dc", 
"apitoken": "QOmwKk-OeCEN5h5_FHPrzjMpiArFXyhpX0IHOsSY"
}, 
"noxxacruel.my.id": {
"zone": "f0d55004d013fa75622e07839a136055", 
"apitoken": "vEfLz6SkwAIFcfUYYQdi8B3eYESWcVMkRmu0GCao"
}, 
"admin-panel.tech": {
"zone": "305d4757160a88486d3780785c7c9887", 
"apitoken": "UH-aDtxu5Mm9oU8khMd5ZVg22f7nhnSkCORBn8zP"
}, 
"nabzxganteng.my.id": {
"zone": "d3aac5354f988960c7280401ec3ef601", 
"apitoken": "wO9i3UGSNCW7Q4PpAXfXwGUIFVxGONuIdDOGSl0b"
}, 
"buyer-vps.site": {
"zone": "354e1c784bed5a8d93f458ec1ff86f35", 
"apitoken": "rzOLIO1c-Me1X0owStLFUZ0ggfs_cxHDab2A7krF"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "4qOupI-Of-6yNrBaeS1-H0KySuKCd0wS-x0P5XQ4"
},
"tokopanel.software": {
"zone": "cc9638d4c289130ba070484625e6aefa", 
"apitoken": "bcAP5z3gHvmQTlQ59qNB9BWmf0JiGt0C99FU6SXs"
},
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "HXVf4soYFM3iiOewHZ6tk6LEnG9f7m7CVhU0EoVz"
},
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "ZPAXx7CL51PtbGweL2pE3BsI3x0hgTgLuy56iXuo"
}
}

global.mess = {
	owner: " *ᴋʜᴜsᴜs ᴏᴡɴᴇʀ* ғɪᴛᴜʀ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ ʙᴀɴɢ ɴᴀʙᴢx",
	admin: " *ᴋʜᴜsᴜs ᴀᴅᴍɪɴ* ғɪᴛᴜʀ ᴋʜᴜsᴜs ᴀᴅᴍɪɴ ʙᴀɴɢ ɴᴀʙᴢx",
	botAdmin: " *ʙᴏᴛ ʙᴜᴋᴀɴ ᴀᴅᴍɪɴ* ғɪᴛᴜʀ ᴛɪᴅᴀᴋ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ʙᴏᴛ ʙᴜᴋᴀɴ ᴀᴅᴍɪɴ",
	group: " *ᴋʜᴜsᴜs ɢʀᴜᴘ* ғɪᴛᴜʀ ɴʏᴀ ᴋʜᴜsᴜs ᴅɪ ɢʀᴏᴜᴘ",
	private: " *ᴋʜᴜsᴜs ᴄʜᴀᴛ ᴘʀɪᴠᴀᴛᴇ* ғɪᴛᴜʀ ɴʏᴀ ᴋʜᴜsᴜs ᴘʀɪᴠᴀᴛᴇ",
	prem: " *ᴋʜᴜsᴜs ᴘʀᴇᴍɪᴜᴍ* ғɪᴛᴜʀ ᴋʜᴜsᴜs ᴘʀᴇᴍɪᴜᴍ",
}
//~~~~~~~~~~~~~~~< PROCESS >~~~~~~~~~~~~~~~\\

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});